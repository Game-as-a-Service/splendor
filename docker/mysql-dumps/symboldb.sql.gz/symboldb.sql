CREATE DATABASE  IF NOT EXISTS `symboldb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `symboldb`;
-- -------------------------------------------------------------
-- TablePlus 4.6.8(424)
--
-- https://tableplus.com/
--
-- Database: symboldb
-- Generation Time: 2022-07-01 15:53:18.2490
-- -------------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP TABLE IF EXISTS `history_bar`;
CREATE TABLE `history_bar` (
  `symbol` char(20) NOT NULL DEFAULT '',
  `time` datetime NOT NULL DEFAULT '1911-01-01 01:01:01',
  `time_frame` char(4) NOT NULL DEFAULT '',
  `open_price` decimal(15,4) DEFAULT NULL,
  `high_price` decimal(15,4) DEFAULT NULL,
  `low_price` decimal(15,4) DEFAULT NULL,
  `close_price` decimal(15,4) DEFAULT NULL,
  `volume` bigint(20) unsigned DEFAULT NULL,
  `adj_open_price` decimal(15,4) DEFAULT NULL,
  `adj_high_price` decimal(15,4) DEFAULT NULL,
  `adj_low_price` decimal(15,4) DEFAULT NULL,
  `adj_close_price` decimal(15,4) DEFAULT NULL,
  `adj_volume` bigint(20) unsigned DEFAULT NULL,
  `return` decimal(15,4) DEFAULT NULL,
  PRIMARY KEY (`symbol`,`time`,`time_frame`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;